from setuptools import setup

setup(
    name="ft_package",
    version="0.0.1",
    author="eagle",
    author_email="eagle@42.fr",
    description="A sample test package",
    url="https://github.com/eagle/ft_package",
    license="MIT",
    metadata_version="2.1",
)
