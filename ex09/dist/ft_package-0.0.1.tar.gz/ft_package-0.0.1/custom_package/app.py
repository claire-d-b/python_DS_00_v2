def count_in_list(lst: list, word: str) -> int:
    return lst.count(word)
